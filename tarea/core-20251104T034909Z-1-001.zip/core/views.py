from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.
from django.views.generic import TemplateView

class HomePageView(TemplateView):
    template_name = 'home.html'

@login_required
def dashboard_view(request):
    # Esta vista solo se ejecuta si el usuario está logueado
    return render(request, 'dashboard.html')